package student;

public class M1Q7Stu {

	// Code a verifier
	public static int eqSolv(int xCube, int xCarre, int x, int tI){
		int r = 0;
		@    @q1@@
		return r;
	}
}