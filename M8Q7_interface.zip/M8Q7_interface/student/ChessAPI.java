package student;
public class ChessAPI {
	public static int deplacerPion(){
		return 42;
	}
	public static int disparaitre(Object mangeur){
    	return 43;
	}
	public static int mangerPion(Object victime){
		return 44;
	}
	
	public static String nomPion(){
		return "pion";
	}
}
